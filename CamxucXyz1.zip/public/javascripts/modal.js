$(".close").click(function() {
  $(this)
    .parent(".alert")
    .fadeOut();
});
$(function() {
  $(".thongbao").hide(7000);
});  
