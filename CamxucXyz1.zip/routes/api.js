var express = require('express');
const session = require('express-session');
var router = express.Router();
var db=require('../models/database'); 
var request = require('request');
/* GET home page. */

router.get('/send', async function(req, res, next) {
    var sql = "SELECT * FROM data"
    db.query(sql, (err, rows) => {  
        rows.forEach(function(x){
            var auth = x.auth;
            var chanel = 'https://discord.com/api/v9/channels/849724925815422979/messages';
            var options = {
                'method': 'POST',
                'url': chanel,
                'headers': {
                  'authorization': auth,
                  'content-type': 'application/json',
                },
                body: '{\r\n    "content": "owoh", \r\n    "nonce": "", \r\n    "tts": false}'
              
              };
               request(options, function (error, response) {
                if (error) {
                }else{
                  console.log('ok')
                }
                });
        });

        
    })
})

router.post('/addAccount', async function(req, res, next) {
  let mail = req.body.mail;
  let auth = req.body.auth;
  let message = req.body.message;
  let token = req.body.token;
  let sql = 'SELECT * FROM account WHERE token = ?';
  db.query(sql, [token] , (err, rows) => {  
    if (err) throw err;
    let user = rows[0];        
    let username = user.username;
    let user_info = [username, mail, auth, message]; 
    let sql2 = 'INSERT INTO data SET username = ?, mail = ?, auth = ?, message = ?'
    db.query(sql2, user_info);
    res.redirect('/');
}); 

})

  
router.post('/getlist', async function(req, res, next) {
  let token = req.body.token;
  let sql = 'SELECT * FROM account WHERE token = ?';
  db.query(sql, [token] , (err, rows) => {  
    if (err) throw err;
  let username = rows[0].username;
  let sql = 'SELECT * FROM data WHERE username = ?';
  db.query(sql, [username] , (err, rows) => {  
    if (rows.length<=0) { res.redirect("/"); return;}
    let user = rows;        
    res.send(user)
});   
  })})

  router.post('/users/delete/', function (req, res) {
    let token = req.body.token;
    let mail = req.body.mail;
    if (!token || !mail) {
     return res.status(400).send({ error: true, message: 'Please provide user_id' });
     
    }
    else{
      let sql = 'SELECT * FROM account WHERE token = ?';
      db.query(sql, [token] , (err, rows) => {  
        if (err) throw err;
      let username = rows[0].username;
      db.query("DELETE FROM data WHERE username = ? AND mail = ?", [username, mail], function (error, results, fields) {
          if (error) throw error;
      });
      
    })}
});

router.post('/users/edit', function (req, res) {
    let token = req.body.token;
    let mail = req.body.mail;
    let auth = req.body.auth;
    let message = req.body.message;
    if (!token || !auth || !message || !mail) {
     return res.status(400).send({ error: true, message: 'Please provide user_id' });
     
    }
    else{
        let sql = 'SELECT * FROM account WHERE token = ?';
        db.query(sql, [token] , (err, rows) => {  
          if (err) throw err;
        let username = rows[0].username;
        db.query("UPDATE data SET auth = ?, message = ? WHERE username = ? AND mail = ?", [auth, message, username, mail], function (error, results, fields) {
            if (error) throw error;
            res.redirect("/");
        });
        
    })
  }
});



module.exports = router;